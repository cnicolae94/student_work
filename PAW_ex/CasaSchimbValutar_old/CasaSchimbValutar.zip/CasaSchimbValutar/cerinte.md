Partea I
1. Definirea claselor necesare aplicației  - 100%
2. Macheta pentru introducerea / actualizarea și ștergerea datelor - 70%
3. Validarea datelor (ErrorProvider control, Validating/Validated events, standard exceptions, custom exceptions) - 40%
4. Acces la câmpuri prin acceleratori, interceptând tastatura - 70% 
5. Implementare serializare / deserializare - 100%
6. Export date în format *csv (sau *txt)  - 100%
7. Dezvoltarea unei interfeţe care să includă următoarele tipuri de meniuri: MenuStrip, ToolStrip, StatusStrip, ContextMenuStrip - 50%

Partea II
8. Reprezentare grafică a unor informații relevante pentru aplicația voastră utilizând clasa System.Drawing.Graphics. Nu utilizați un control de tip chart existent, cum ar fi cel disponibil în ToolBox (scopul este să creați singuri un astfel de control). Controlul ar trebui să fie diferit de cele disponibile pe http://github.com/liviucotfas (discutate în timpul cursului / în timpul laboratoarelor). Puteți verifica chart-urile disponibile în Microsoft Excel pentru inspirație. - 0%
9. Posibilitate imprimare document cu mai multe pagini si previzualizare (PrintPreview) - 100%
10. Implementare Drag & Drop și lucru cu Clipboard - 50%

Partea III
11. Stocarea și regăsirea datelor într-o bază de date pentru cel puțin două clase din aplicația voastră. Se vor implementa toate cele patru tipuri de operații: SELECT, UPDATE, INSERT, DELETE. - 100%
12. Implementați un UserControl într-un proiect separat (astfel încât să poată fi distribuit altor dezvoltatori) și utilizați-l în aplicația dvs. UserControl ar trebui să ofere o funcționalitate utilă pentru aplicația voastră - 0%